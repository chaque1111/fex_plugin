<?php
/**
 * Loading the admin file
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

require_once USER_IP_AND_LOCATION_ADMIN_PATH . 'user-ip-menu.php';
require_once USER_IP_AND_LOCATION_ADMIN_PATH . 'user-ip-menu-options.php';
